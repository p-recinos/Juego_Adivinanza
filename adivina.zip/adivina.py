import tkinter as tk
import random

class AdivinaElNumero:
    def __init__(self, root):
        self.root = root
        self.root.title("Adivina el Número")
        self.root.geometry("400x500")
        self.root.configure(bg='#ADD8E6')
        
        self.numero_secreto = random.randint(1, 100)
        self.intentos = 0
        self.max_intentos = 10  # Valor por defecto (para dificultad fácil)
        self.idioma = "es"
        self.dificultad = "medio"
        
        self.textos = {
            "es": {"titulo": "Adivina un número del 1 al 100", "adivinar": "Adivinar", "bajo": "Demasiado bajo", "alto": "Demasiado alto", "correcto": "¡Correcto en {} intentos!", "ingrese": "Ingrese un número válido", "jugar": "Jugar", "lenguaje": "Lenguaje", "dificultad": "Dificultad", "facil": "Fácil", "medio": "Medio", "dificil": "Difícil", "sin_intentos": "¡Se acabaron los intentos! El número era: {}"},
            "en": {"titulo": "Guess a number from 1 to 100", "adivinar": "Guess", "bajo": "Too low", "alto": "Too high", "correcto": "Correct in {} attempts!", "ingrese": "Enter a valid number", "jugar": "Play", "lenguaje": "Language", "dificultad": "Difficulty", "facil": "Easy", "medio": "Medium", "dificil": "Hard", "sin_intentos": "Out of attempts! The number was: {}"},
            "de": {"titulo": "Rate eine Zahl von 1 bis 100", "adivinar": "Raten", "bajo": "Zu niedrig", "alto": "Zu hoch", "correcto": "Korrekt in {} Versuchen!", "ingrese": "Geben Sie eine gültige Zahl ein", "jugar": "Spielen", "lenguaje": "Sprache", "dificultad": "Schwierigkeit", "facil": "Einfach", "medio": "Mittel", "dificil": "Schwer", "sin_intentos": "Keine Versuche mehr! Die Zahl war: {}"}
        }
        
        self.dificultad_colores = {"facil": "green", "medio": "orange", "dificil": "red"}
        self.idioma_colores = {"es": "#FF0000", "en": "#3C3B6E", "de": "#000000"}
        
        # Etiqueta de título
        self.label = tk.Label(root, text=self.textos[self.idioma]["titulo"], font=("Arial", 14), bg='#ADD8E6')
        self.label.pack(pady=10)
        
        # Botón jugar
        self.button_play = tk.Button(root, text=self.textos[self.idioma]["jugar"], font=("Arial", 12), command=self.reiniciar_juego)
        self.button_play.pack(pady=5)
        
        self.button_language = tk.Button(root, text=self.textos[self.idioma]["lenguaje"], font=("Arial", 12), command=self.cambiar_idioma, bg=self.idioma_colores[self.idioma], fg='white', width=10, height=2)
        self.button_language.pack(pady=5)
        
        self.button_difficulty = tk.Button(root, text=self.textos[self.idioma][self.dificultad], font=("Arial", 12), command=self.cambiar_dificultad, bg=self.dificultad_colores[self.dificultad], fg='white')
        self.button_difficulty.pack(pady=5)
        
        self.abrir_ventana_ingreso()

    def abrir_ventana_ingreso(self):
        self.ventana_ingreso = tk.Toplevel(self.root)
        self.ventana_ingreso.title("Ingresar número")
        self.ventana_ingreso.geometry("300x250")
        self.ventana_ingreso.configure(bg='#F0E68C')
        
        # Etiqueta de ayuda
        self.label_ayuda = tk.Label(self.ventana_ingreso, text="Ingrese un número entre 1 y 100", font=("Arial", 12), bg='#F0E68C')
        self.label_ayuda.pack(pady=10)
        
        self.entry = tk.Entry(self.ventana_ingreso, font=("Arial", 14))
        self.entry.pack(pady=5)
        
        self.button_guess = tk.Button(self.ventana_ingreso, text=self.textos[self.idioma]["adivinar"], font=("Arial", 12), command=self.verificar_numero)
        self.button_guess.pack(pady=5)
    
    def verificar_numero(self):
        if self.intentos >= self.max_intentos:
            self.label.config(text=self.textos[self.idioma]["sin_intentos"].format(self.numero_secreto), fg='red')
            return
        
        try:
            numero = int(self.entry.get())
            self.intentos += 1
            if numero < self.numero_secreto:
                self.label.config(text=self.textos[self.idioma]["bajo"], fg='red')
            elif numero > self.numero_secreto:
                self.label.config(text=self.textos[self.idioma]["alto"], fg='red')
            else:
                self.label.config(text=self.textos[self.idioma]["correcto"].format(self.intentos), fg='green')
                self.mostrar_confeti()  # Mostrar confeti cuando acierte
        except ValueError:
            self.label.config(text=self.textos[self.idioma]["ingrese"], fg='red')
    
    def mostrar_confeti(self):
        self.confeti_particles = []  # List to store confetti particles
        for _ in range(50):
            color = random.choice(['red', 'green', 'blue', 'yellow', 'purple', 'orange'])
            x = random.randint(0, 400)
            y = random.randint(50, 400)
            dx = random.randint(-5, 5)  # Velocidad horizontal
            dy = random.randint(1, 5)   # Velocidad vertical
            self.confeti_particles.append([x, y, dx, dy, color])
        self.animar_confeti()
    
    def animar_confeti(self):
        for particle in self.confeti_particles:
            x, y, dx, dy, color = particle
            # Crear el confeti en el canvas
            confeti = tk.Canvas(self.root, width=10, height=10, bg=color, bd=0, highlightthickness=0)
            confeti.place(x=x, y=y)
            
            # Actualizar la posición del confeti para darle movimiento
            x += dx
            y += dy
            particle[0] = x
            particle[1] = y
            
            # Mover confeti en la pantalla
            confeti.place(x=x, y=y)
            
            # Volver a mover el confeti después de un pequeño intervalo
            self.root.after(20, self.animar_confeti)
        
        # Eliminar el confeti después de un tiempo
        self.root.after(3000, self.eliminar_confeti)

    def eliminar_confeti(self):
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Canvas):
                widget.destroy()
    
    def reiniciar_juego(self):
        self.numero_secreto = random.randint(1, 100)
        self.intentos = 0
        self.label.config(text=self.textos[self.idioma]["titulo"])
        if self.ventana_ingreso:
            self.ventana_ingreso.destroy()
        self.abrir_ventana_ingreso()
    
    def cambiar_idioma(self):
        opciones = list(self.textos.keys())
        index_actual = opciones.index(self.idioma)
        self.idioma = opciones[(index_actual + 1) % len(opciones)]
        self.actualizar_textos()
    
    def cambiar_dificultad(self):
        niveles = ["facil", "medio", "dificil"]
        index_actual = niveles.index(self.dificultad)
        self.dificultad = niveles[(index_actual + 1) % len(niveles)]
        
        # Cambiar el número de intentos según la dificultad
        if self.dificultad == "facil":
            self.max_intentos = 10
        elif self.dificultad == "medio":
            self.max_intentos = 5
        else:  # dificil
            self.max_intentos = 3
        
        self.button_difficulty.config(text=self.textos[self.idioma][self.dificultad], bg=self.dificultad_colores[self.dificultad])
    
    def actualizar_textos(self):
        self.label.config(text=self.textos[self.idioma]["titulo"])
        self.button_guess.config(text=self.textos[self.idioma]["adivinar"])
        self.button_play.config(text=self.textos[self.idioma]["jugar"])
        self.button_difficulty.config(text=self.textos[self.idioma][self.dificultad])
        self.button_language.config(text=self.textos[self.idioma]["lenguaje"], bg=self.idioma_colores[self.idioma])
    
if __name__ == "__main__":
    root = tk.Tk()
    app = AdivinaElNumero(root)
    root.mainloop()
